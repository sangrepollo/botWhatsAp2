
------------------$------------------$------------------$-----------------$ 

🤙🏻😎Hola a todos, Les Saluda Juls Modders.
Soy el creador Oficial del Bot : Mafuyu.

Para usarlo correctamente Instala los comandos 
en Térmux ( De preferencia 119)

------------------$------------------$------------------$-----------------$ 
   🕵️ COMANDOS 🕵️
------------------$------------------$------------------$-----------------$ 

COMANDO # (1) - - - - - - - - - - - - 

-----------------$------------------$------------------$-----------------$ 

pkg upgrade -y && pkg update -y && pkg install git -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install tesseract -y && pkg install python -y && npm i -g npm@6 

⚠️NOTA: SI TE SALE ALGÚN TEXTO , LE DAS LA LETRA " y " y luego enter con tu teclado. ( Déjalo que sólo el haga su trabajo). Recuerda que el comando termina cuando salga el signo de dinero. "$"

-----------------$------------------$------------------$-----------------$ 

$ COMANDO #(2)------------------------
-----------------$------------------$------------------$-----------------$ 

termux-setup-storage

⚠️NOTA: SI TE SALE ALGÚN TEXTO , LE DAS LA LETRA " y " y luego enter con tu teclado.

-----------------$------------------$------------------$-----------------$ 

$ COMANDO #(3) - - - - - - - - - - - - 

-----------------$------------------$------------------$-----------------$ 

cd /sdcard/mafuyu-v1

⚠️🗣️ Éste comando es si esque descomprimiste el bot en tu carpeta interna.

cd /sdcard/download/mafuyu-v1

⚠️🗣️ Éste comando es ,si esque descomprimiste el bot en la carpeta dowloan o descargas.


⚠️🗣️ cualquier de las dos debe funcionar. y como me doy cuenta? , bueno si esque el texto se pone de color verde . ahora si no funciona asegúrate 1) que no haya doble carpeta , si no una sola.  2) que hayas descomprimido correctamente en alguno de los dos lugares requeridos.

-----------------$------------------$------------------$-----------------$ 

$ COMANDO (#4) - - - - - - - - - - - -

-----------------$------------------$------------------$-----------------$ 

sh start.sh

-----------------$------------------$------------------$-----------------$ 

- LISTO AHORA TE SALDRA UN CÓDIGO QR , LO ESCANEAS Y TODO ESTARÁ CORRECTAMENTE , ESPERO TW GUSTE 🕵️

-----------------$------------------$------------------$-----------------$ 

AQUÍ TE DEJO UN TUTORIAL EN CASO NO SABES COMO PONER LOS COMANDOS O COMO SCANEAR EL CÓDIGO QR.

https://m.youtube.com/watch?v=gPr-BuXby9w&feature=youtu.be

-----------------$------------------$------------------$-----------------$ 

ÚNICO PROPIETARIO Y CREADOR DEL BOT:

JULS MODDERS OFC
-----------------$------------------$--------------🏆️----$-----------------🏆 
-----------------$----------🏆--------$------------------$-----------------$ 
---------🏆--------$------------------$------------------$-----------------$ 