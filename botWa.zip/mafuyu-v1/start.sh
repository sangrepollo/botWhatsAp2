#!bin/bash
verde="\033[0;32m"
while : 
do
echo "${verde}Iniciando mafuyu bot, esperé porfavor 🤙🏻🥺..."
    node mafuyu.js
    sleep 1

done


#sistema para o bot não cair
# de sh start.sh no termux!!