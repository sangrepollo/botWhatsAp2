const mintake = require("./src/index");

// zrapi.pastegg("Z", )
mintake.snaptik("https://vt.tiktok.com/khpq9t")
.then(data => console.log(data))
.catch(e => console.log(e))
